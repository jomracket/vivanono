
                        v i v a   n o n n o

                      namco System 22 Emulator

                          version 22.0.3

                   http://vivanonno.vg-network.com


System Requirements
-------------------
- CPU : 1GHz(minimum) or over 1.5GHz(recommended)

- VGA : DirectX7 support is required.
        GeForce class VGA is recommended.

	Video Memory : 32MB(recommended)
	(256MB or more memory required for no-reducted texture.)

- Sound : DirectSound support is required.


Supported Titles
----------------
- "Ridge Racer 2" (Japan-A, Japan-B) (1994)
- "Rave Racer"    (Japan-A, Japan-B, World-B) (1995)
 ("Ridge Racer" is not supported.)


Install
-------
- put vivanonno.exe and ROM images in proper directory.
  see also rominfo.txt attached with this file.

    |- vivanonno.exe
    |- settings.xml                <- generated automatically
    |- eeprom/                     <- EEPROM images are saved here
    |- roms/                       <- place ROM images here
         |- rrs1/ or rrs1.zip      <- "Ridge Racer 2" (Japan) directory or zip
         |- rv1/ or rv1.zip        <- "Rave Racer" (Japan) directory or zip
         |- rv2/ or rv2.zip        <- "Rave Racer" (World) directory or zip

* Note *
if you have a trouble of reading files from zip,
please try to extract to proper directory and remove the zip from roms directory.


Attention
---------
- old settings.xml file may be overwritten by the default value.
- when you have a first play, it is recommended to initialize EEPROM in TEST MODE.


Keys
----
Left/Right	Steering left/right
Up/Down		Shift down/up
C		Gas (Accelerator) pedal
X		Brake pedal
V		VIEW Switch (Rave Racer)

Q		SERVICE Switch (inserts a credit)
T		Toggles the TEST Switch

S		Pauses the game
Alt+Enter	Toggles the full-screen/window mode.


Menu
----
File/Load	Loads the game
File/Reset	Resets the system
File/Exit	Exits viva nonno

Setting/Graphics Setting
	Texture Format
		Specifies a texture format.

	Texture Reduction
		Specifies a texture resolution.

	Gamma Correction
		Adjusts the gamma correction of rendering.

	No Wait
		Disables to lock frame rate to 60Hz.
		(It is recommended to check when full-screen mode.)
		The default is not checked.

	Show FPS
		Display FPS value.

	Fake Interlace
		Simulates interlaced display.

	Texture Filtering
		Enables bi-linear texture filtering.

	Depth Bias
		Simulates rendering with depth bias.
		(normally, checked)

	Use MIPMAP
		Enables MIPMAP texture filtering.
		(more texture buffer is required.)

Setting/Sound Setting
	Enable Sound Emulation
		Enables sound emulation and playback.

	Playback Freq (Hz)
		Specifies a sound playback frequency.
		The default is 44100Hz.
		(42667Hz is the same freq as the D/A clock of the real system)

	Sound Buffer Size (ms)
		Specifies the size of sound buffer in milli-seconds.
		The default is 200msec.

	Volume
		* This control doesn't work *
		Please set the volume in each TEST MODE of the games.
		The default of VOLUME(R/L) value is 20H (= 32).

Setting/Toggle Full Screen Mode
		Enter/Leaves full screen mode. (ALT + Enter)

Sound/Sound Test
		Opens sound-test dialog.


To Get More Close Emulation
---------------------------
- minimize texture-reduction
- disable texture-filtering, MIPMAP
- check No Wait (to synchronize with display reflesh in the full-screen mode)
- check Fake Interlace
- minimize sound buffer size (100ms or smaller)
- enter full-screen mode
- use analog controller :)


Manual Controller Configuration
-------------------------------
1. run viva nonno once, and exit.
2. edit settings.xml and save it.
3. run viva nonno again.
4. to adjust the center, hold down the service switch and press the test button.


(ex. config for namco negcon (+ PS Joypad mini))

<joystick>
<axis handle="Z" gas="RZ" brake="X"/>
<button coin1="8" coin2="9" clutch="4" shift1="12" shift2="14" shift3="15" shift4="13" shift_up="7" shift_down="Y0" test="0" service="1" view_change="5" pause="11"/>
</joystick>

* note *
to reverse direction, add '-' in front of axis name.


Changes
-------
22.0.1	19 Jul 2002	first release

22.0.2	 1 Aug 2002	minor version up
			some problems might be fixed.
			- setting dialog didn't open in some versions of windows
			- failed to enter full-screen mode

			the sound emulation was improved. (not completed)
			- eliminated pop-up noise
			- tuned interpolation filter
			- fixed handling of SEs

			added "Use MIPMAP" check box in the gfx setting.

22.0.3  20 Aug 2002	minor version up
			RRS1 (Japan-B), RV1 (Japan-A, World-B) were supported.
			CRC of RV1CG1.BIN was fixed (by courtesy of Team AnkokuFuumi and The Guru)


Future Work
-----------
- Z-sorted rendering
- Depth Bias emulation
- Depth-cueing table emulation
- More correct sound emulation
- Link battle
- Controller configuration GUI
- DIP SW


Acknowledgements
----------------
"viva nonno" is builded with
M680x0 emulation engine "MUSASHI" version 3.3
Copyright 1998-2001 Karl Stenerud.

the CRC of RR1 files are provided by Team AnkokuFuumi.
the correct CRC of RV1CG1 file was provided courtesy of Team AnkokuFuumi and The Guru.
the information of RV2 file was provided courtesy of The Guru.


How To Contact Us
-----------------
viva nonno official homepage:
http://vivanonno.vg-network.com

see also official forum at:
http://www.vg-network.com

e-mail address:
mailto:vivanonno@hotmail.com

** I will ignore all emails about ROM images.
** please do not email me any binary attachments, thank you.

EOF
